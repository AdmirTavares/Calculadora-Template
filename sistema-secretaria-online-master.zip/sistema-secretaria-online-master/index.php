<?php 

    header("Location: views\site\home.php");

