<h1>Sistema de Secretária Online</h1>

Objetivo: Sistema de Secretário. O Aluno vai conseguir ver seu boletim e outras coisas. O sistema é dívidido em níveis de acesso
cada nível responsávei por algo.

<a href="https://www.dbdesigner.net/designer/schema/172463">Modelagem do banco de dados</a>

<i>Níveis de acesso:</i>

<b>Aluno</b>
  <ul>
    <li>Ver dados pessoais;</li>
    <li>Ver atividades passadas pelos professores;</li>
    <li>Ver o boletim.</li>
  </li>
  </ul>
  
<b>Professor</b>
  <ul>
    <li>Ver dados pessoais;</li>
    <li>Listar os alunos | Cadastrar Notas;</li>
    <li>Passar Atividades</li>
  </ul>
 
<b>Responsáveis do Aluno</b>
<ul>
  <li>Ver os boletin dos alunos depedentes</li>
</ul>

<b>Coordenador</b>
<ul>
    <li>Cadastrar alunos| editar | visualizar;</li>
    <li>Cadastrar responsáveis dos alunos</li>
</ul>

<b>Moderadores</b>
<ul>
    <li>CRUD Alunos</li>
    <li>CRUD Professores</li>
    <li>CRUD Coordenador</li>
    <li>CRUD Responsáveis</li>
    <li>Cadastrar notas dos alunos</li>
    <li>Cadastrar outros moderadores</li>
</ul>

<b>Empresas</b>
<ul>
    <li>CRUD</li>
</ul>

<b>Contatos</b>
<ul>
  <li>Listar Contatos e seus devidos comentários</li>
  <li>Excluir contato</li>
</ul>
