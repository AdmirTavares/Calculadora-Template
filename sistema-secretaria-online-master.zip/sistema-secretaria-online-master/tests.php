<?php 


	include_once 'app/models/Admin.php';

	//verificarLoginAdmin("teste@gmail.com", '123456');

	echo crypt('123456');